

User task management system

Registration

Name -

Email - It should be unique and email validation rule

password - both password should same

confirm password-> both password should same

profile pic

Date of birth -> It should be more than 18 years


Login

Email

password


Create tods task

Name

Description

start date

end date

task status pending/complted


Edit task


List my tasks (Pending/completed)
